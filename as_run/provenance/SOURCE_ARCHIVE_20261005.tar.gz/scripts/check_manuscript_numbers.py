"""Check that key numbers in the article and its supplement match the sealed summaries (A-121).

Each check formats a value from a summary JSON and looks for it in the normalised LaTeX source
("$-$" -> "-", math and spacing commands removed). Prints a table and exits non-zero on a mismatch.
"""

from __future__ import annotations

import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXP = os.path.join(ROOT, "experiments")


def load(*p):
    path = os.path.join(EXP, *p)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as h:
        return json.load(h)


def norm(tex):
    tex = (
        tex.replace("$-$", "-")
        .replace("\\%", "%")
        .replace("\\,", "")
        .replace("$", "")
        .replace("{", "")
        .replace("}", "")
    )
    tex = re.sub(r"\s+", " ", tex)
    return tex


def f3(x):
    return f"{x:.3f}"


def iv(lo, hi, nd=3):
    return f"[{lo:.{nd}f}, {hi:.{nd}f}]"


def pct(x, nd=1):
    return f"{100 * x:.{nd}f}"


def piv(b):
    return f"[{pct(b[0])}, {pct(b[1])}]"


def main() -> int:
    # The article and its supplement are checked together: detail moved to the supplement must
    # still match the sealed summaries.
    tex = ""
    for name in ("main.tex", "supplement.tex"):
        path = os.path.join(ROOT, "docs", "manuscript", "ieee", name)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as h:
                tex += " " + norm(h.read())
    checks = []
    a1 = load("20261004_audit_addendum_r01", "ADDENDUM_SUMMARY.json")
    if a1:
        b4 = a1["B4"]
        h1 = b4["TEST_H1_plb_minus_pursuit"]
        checks += [
            ("H1 estimate", f3(h1["family_97.5"][0])),
            ("H1 family 97.5", iv(*h1["family_97.5"][1:])),
            ("H1 city-family 95", iv(*h1["city_family_95"][1:])),
            ("H2 estimate", f3(b4["TEST_H2_prox5_minus_pc_pursuit"]["family_97.5"][0])),
            ("H2 family 97.5", iv(*b4["TEST_H2_prox5_minus_pc_pursuit"]["family_97.5"][1:])),
            ("S2 optimal TEST", iv(*b4["TEST_S2_optimal_plb_minus_pursuit"]["family_95"][1:])),
            ("OX optimal", iv(*b4["OX_optimal_plb_minus_pursuit"]["family_95"][1:])),
            ("Goal family", iv(*b4["GOAL_plb_minus_pursuit"]["family_95"][1:])),
            (
                "A-99 primary city-family",
                iv(*b4["A99_plb_minus_a95 (A-99 primary)"]["city_family_95"][1:]),
            ),
        ]
    a2 = load("20261004_audit_addendum_r02", "ADDENDUM_R02_SUMMARY.json")
    if a2:
        ni = a2["N_I"]
        nd = ni["null_d06"]
        checks += [
            (
                "Null OC",
                f"{pct(nd['observed'])}% [{pct(nd['family_95'][0])}, {pct(nd['family_95'][1])}]",
            ),
            ("Lane TEST joint", piv(ni["B2T_lane_nv_joint"]["family_95"])),
            ("Junction A-91 joint", piv(ni["B2F_junction_joint"]["family_95"])),
            ("Persistence families", str(a2["P"]["families_scenario_evader"])),
            ("KAN TEST AUC", f"{a2['K']['splits']['TEST']['observed_auc']['kan']:.3f}"),
        ]
    mv = load("20261004_mappo_v2_r01", "summary.json")
    if mv:
        for head in ("mlp", "kan"):
            d = mv["primary"][head]["minus_planner_97.5"]
            checks.append((f"MAPPO-v2 {head}", iv(d[1], d[2])))
    a3 = load("20261004_audit_addendum_r03", "ADDENDUM_R03_SUMMARY.json")
    if a3:
        p = a3["AB"]["primary_pooled"]
        checks.append(("AB primary", iv(p[1], p[2])))
    pe = load("20261005_published_env_audit_r01", "summary.json")
    if pe:
        for cell, label in (
            ("3x3Traffic_4_2|null", "Published env null 4v2"),
            ("3x3Traffic_4_2|greedy", "Published env chaser 4v2"),
            ("3x3Traffic_7_4|null", "Published env null 7v4"),
            ("3x3Traffic_7_4|greedy", "Published env chaser 7v4"),
        ):
            b = pe["cells"][cell]
            sc = b["published"]["success"]
            checks.append((label, f"{pct(sc[0])}% {piv(sc[1:])}"))
            far = b["followup"]["marks"]["+10s"]["over_50m_from_every_pursuer"]
            checks.append((label + " +10 s", f"{pct(far[0])}% {piv(far[1:])}"))
        n_events = sum(b["published"]["capture_events"] for b in pe["cells"].values())
        checks.append(("Published env events", f"{n_events} over both"))
    mp_ = load("20261005_mappo_prox_r01", "summary.json")
    if mp_:
        g = mp_["primary"]["gap_prox_minus_oc__prox_trained_minus_oc_trained"]
        checks.append(("Prox-trained primary", f"+{g[0]:.3f} {iv(g[1], g[2])}"))
        d = mp_["secondary"]["d06:prox_trained_minus_oc_trained"]
        checks.append(("Prox-trained OC loss", f"{d[0]:.3f} {iv(d[1], d[2])}"))
        for name, key in (
            ("PLB-pursuit OC (PE19)", "d06:plb_minus_pursuit"),
            ("PLB-pursuit 5 m", "prox_5m:plb_minus_pursuit"),
        ):
            d = mp_["secondary"][key]
            checks.append((name, iv(d[1], d[2])))
    ks = load("20261005_kinematic_sensitivity_r01", "summary.json")
    if ks:
        for variant in ("K0", "K1", "K2"):
            d = ks["variants"][variant]["plb_minus_pursuit_family_95"]
            checks.append((f"Kinematics {variant}", f"+{d[0]:.3f} {iv(d[1], d[2])}"))
    tr = load("20261005_traffic_sensitivity_r01", "summary.json")
    if tr:
        d = tr["primary_plb_minus_pursuit_traffic_family_95"]
        checks.append(("Traffic primary", f"+{d[0]:.3f} {iv(d[1], d[2])}"))
        d = tr["traffic_minus_no_traffic_plb_family_95"]
        checks.append(("Traffic effect on PLB", f"{d[0]:.3f} {iv(d[1], d[2])}"))
    te = load("20261005_tuned_evader_r01", "summary.json")
    if te:
        d = te["primary_plb_minus_pursuit_vs_tuned_family_95"]
        checks.append(("Tuned evader primary", f"+{d[0]:.3f} {iv(d[1], d[2])}"))
        d = te["primary_city_family_95"]
        checks.append(("Tuned evader city-family", iv(d[1], d[2])))
        d = te["plb_tuned_minus_reference_family_95"]
        checks.append(("Tuned minus reference", iv(d[1], d[2])))
    bad = 0
    for name, s in checks:
        ok = s in tex
        bad += not ok
        print(f"{'OK ' if ok else 'MISSING'}  {name:28s} {s}")
    print(f"{len(checks) - bad}/{len(checks)} found")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
