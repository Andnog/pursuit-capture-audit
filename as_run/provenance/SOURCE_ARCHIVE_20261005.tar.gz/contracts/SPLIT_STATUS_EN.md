# Split status (current)

`split_manifest.json` is a historical, hashed manifest and is not rewritten. Its `CLOSED` state for TEST describes the
split before A-110.

| Split | Cities | Status (2026-10-04) |
|---|---|---|
| TRAINING | adelaide_cbd, toronto_downtown, washington_downtown, seattle_downtown | used for development, search and training |
| DEVELOPMENT | phoenix_downtown, portland_downtown, sapporo_grid | used for evaluation; informed design decisions after A-88, so not an untouched hold-out |
| TEST | chicago_loop, melbourne_cbd, salt_lake_city, minneapolis_downtown | opened once (A-110, Research lead), single-shot confirmation sealed in `experiments/20261003_test_confirmation_r01` (A-111); **spent**. Only deterministic replays completing follow-up of those sealed audits are admissible (A-115); no new TEST evaluation. |
