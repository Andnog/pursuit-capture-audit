"""Check that key numbers in docs/manuscript/ieee/main.tex match the sealed summaries (A-121).

Each check formats a value from a summary JSON and looks for it in the normalised LaTeX source
("$-$" -> "-", math and spacing commands removed). Prints a table and exits non-zero on a mismatch.
"""

from __future__ import annotations

import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXP = os.path.join(ROOT, "experiments")


def load(*p):
    path = os.path.join(EXP, *p)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as h:
        return json.load(h)


def norm(tex):
    tex = (
        tex.replace("$-$", "-")
        .replace("\\%", "%")
        .replace("\\,", "")
        .replace("$", "")
        .replace("{", "")
        .replace("}", "")
    )
    tex = re.sub(r"\s+", " ", tex)
    return tex


def f3(x):
    return f"{x:.3f}"


def iv(lo, hi, nd=3):
    return f"[{lo:.{nd}f}, {hi:.{nd}f}]"


def pct(x, nd=1):
    return f"{100 * x:.{nd}f}"


def piv(b):
    return f"[{pct(b[0])}, {pct(b[1])}]"


def main() -> int:
    with open(os.path.join(ROOT, "docs", "manuscript", "ieee", "main.tex"), encoding="utf-8") as h:
        tex = norm(h.read())
    checks = []
    a1 = load("20261004_audit_addendum_r01", "ADDENDUM_SUMMARY.json")
    if a1:
        b4 = a1["B4"]
        h1 = b4["TEST_H1_plb_minus_pursuit"]
        checks += [
            ("H1 estimate", f3(h1["family_97.5"][0])),
            ("H1 family 97.5", iv(*h1["family_97.5"][1:])),
            ("H1 city-family 95", iv(*h1["city_family_95"][1:])),
            ("H2 estimate", f3(b4["TEST_H2_prox5_minus_pc_pursuit"]["family_97.5"][0])),
            ("H2 family 97.5", iv(*b4["TEST_H2_prox5_minus_pc_pursuit"]["family_97.5"][1:])),
            ("S2 optimal TEST", iv(*b4["TEST_S2_optimal_plb_minus_pursuit"]["family_95"][1:])),
            ("OX optimal", iv(*b4["OX_optimal_plb_minus_pursuit"]["family_95"][1:])),
            ("Goal family", iv(*b4["GOAL_plb_minus_pursuit"]["family_95"][1:])),
            (
                "A-99 primary city-family",
                iv(*b4["A99_plb_minus_a95 (A-99 primary)"]["city_family_95"][1:]),
            ),
        ]
    a2 = load("20261004_audit_addendum_r02", "ADDENDUM_R02_SUMMARY.json")
    if a2:
        ni = a2["N_I"]
        nd = ni["null_d06"]
        checks += [
            (
                "Null OC",
                f"{pct(nd['observed'])}% [{pct(nd['family_95'][0])}, {pct(nd['family_95'][1])}]",
            ),
            ("Lane TEST joint", piv(ni["B2T_lane_nv_joint"]["family_95"])),
            ("Junction A-91 joint", piv(ni["B2F_junction_joint"]["family_95"])),
            ("Persistence families", str(a2["P"]["families_scenario_evader"])),
            ("KAN TEST AUC", f"{a2['K']['splits']['TEST']['observed_auc']['kan']:.3f}"),
        ]
    mv = load("20261004_mappo_v2_r01", "summary.json")
    if mv:
        for head in ("mlp", "kan"):
            d = mv["primary"][head]["minus_planner_97.5"]
            checks.append((f"MAPPO-v2 {head}", iv(d[1], d[2])))
    a3 = load("20261004_audit_addendum_r03", "ADDENDUM_R03_SUMMARY.json")
    if a3:
        p = a3["AB"]["primary_pooled"]
        checks.append(("AB primary", iv(p[1], p[2])))
    bad = 0
    for name, s in checks:
        ok = s in tex
        bad += not ok
        print(f"{'OK ' if ok else 'MISSING'}  {name:28s} {s}")
    print(f"{len(checks) - bad}/{len(checks)} found")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
