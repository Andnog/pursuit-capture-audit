"""Record the inputs of an evidence package at launch, and seal it when its writers have ended.

    uv run python scripts/package_tools.py register --package experiments/X --amendment A-137 \
        --source scripts/a.py --source src/b.py [--note key=value ...]
    uv run python scripts/package_tools.py seal --package experiments/X
    uv run python scripts/package_tools.py verify --package experiments/X

`register` refuses to overwrite an existing inputs.json; `seal` refuses to overwrite a seal. The
formats are those of the packages sealed by hand before this script existed (A-137).
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def register(package, amendment, sources, notes):
    path = os.path.join(ROOT, package, "inputs.json")
    if os.path.exists(path):
        raise SystemExit(f"{path} exists; inputs are recorded once, at launch")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    out = {
        "schema_version": 1,
        "experiment_id": os.path.basename(package.rstrip("/")),
        "recorded_at_launch": now(),
        "amendment": amendment,
        "sources": {s: sha256(os.path.join(ROOT, s)) for s in sorted(set(sources))},
    }
    out.update(notes)
    with open(path, "w", encoding="utf-8") as h:
        json.dump(out, h, indent=1)
    return out


def files_of(package):
    base = os.path.join(ROOT, package)
    out = {}
    for folder, _, names in os.walk(base):
        for name in names:
            rel = os.path.relpath(os.path.join(folder, name), base)
            if rel != "checksums.json" and not name.startswith("."):
                out[rel] = sha256(os.path.join(folder, name))
    return dict(sorted(out.items()))


def seal(package):
    path = os.path.join(ROOT, package, "checksums.json")
    if os.path.exists(path):
        raise SystemExit(f"{path} exists; a sealed package is not resealed")
    out = {
        "schema_version": 1,
        "experiment_id": os.path.basename(package.rstrip("/")),
        "sealed_at": now(),
        "algorithm": "sha256",
        "sealed_after_all_writers_ended": True,
        "excludes_itself": True,
        "files": files_of(package),
    }
    with open(path, "w", encoding="utf-8") as h:
        json.dump(out, h, indent=1)
    return out


def verify(package):
    with open(os.path.join(ROOT, package, "checksums.json"), encoding="utf-8") as h:
        sealed = json.load(h)["files"]
    current = files_of(package)
    return {
        "files": len(sealed),
        "changed": sorted(k for k in sealed if k in current and current[k] != sealed[k]),
        "missing": sorted(k for k in sealed if k not in current),
        "unsealed": sorted(k for k in current if k not in sealed),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["register", "seal", "verify"])
    parser.add_argument("--package", required=True)
    parser.add_argument("--amendment", default="")
    parser.add_argument("--source", action="append", default=[])
    parser.add_argument("--note", action="append", default=[])
    args = parser.parse_args()
    if args.action == "register":
        notes = dict(n.split("=", 1) for n in args.note)
        out = register(args.package, args.amendment, args.source, notes)
        print(json.dumps({"registered": len(out["sources"])}))
    elif args.action == "seal":
        print(json.dumps({"sealed_files": len(seal(args.package)["files"])}))
    else:
        out = verify(args.package)
        print(json.dumps(out))
        return 1 if out["changed"] or out["missing"] else 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
